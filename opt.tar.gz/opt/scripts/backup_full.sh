#!/bin/bash

info () {
	echo -e "NOMBRE\n\tbackup_full.sh - crear una copia de respaldo comprimida de un directorio.\n\n"
	echo -e "SINOPSIS\n\tUso\n\t./backup_full.sh [DIRECTORIO DE ORIGEN] [DIRECTORIO DE DESTINO]\n\n"
	echo -e "DESCRIPCIÓN\n\tComprime los archivos del DIRECTORIO DE ORIGEN mediante tar y gzip, y almacena el resultado en el DIRECTORIO DE DESTINO.\n\t El archivo resultante lleva el nombre \"bkp_<origen>_<fecha en YYYYmmdd>.tar.gz\".\n\n\t--help\n\t\tMuestra esta página de ayuda."
	exit 1
}

backup () {
	echo "Creando copia de seguridad de ${1} en ${2}..."
	# Obtener nombre del directorio
	local DIRNAME=$(grep -E -o '[^\/]+$' <<< $1)
	# Obtener fecha
	local DATE=$(date +"%Y%m%d")

	# Generar nombre de archivo
	local FILENAME="${DIRNAME}_bkp_${DATE}"

	# Generar Tarball
	tar -cvf /tmp/$FILENAME.tar $1 > /dev/null
	# Comprimir tarball y guardar
	gzip /tmp/$FILENAME.tar
	# Mover el archivo comprimido.
	mv /tmp/$FILENAME.tar.gz $2/$FILENAME.tar.gz

	echo "Copia de seguridad de ${DIRNAME} completada. Se creó el archivo ${2}/${FILENAME}.tar.gz."
}

# Validación de parámetros
if [ $# -lt 2 ];
then
	if [ $# == 1 ] && [ $1 == "--help" ];
	then
		info
		exit 0
	fi
fi

if [ $# == 2 ];
then
	if [ ! -d $1 ];
	then
		echo "ERROR: El directorio de origen (${1}) no existe."
		exit 1
	fi
	if [ ! -d $2 ];
	then
		echo "ERROR: El directorio de destino (${2}) no existe."
		exit 1
	fi
	backup $1 $2
	exit 0
fi
echo "ERROR: Los parámetros ingresados no son correctos. Utilice la opción --help para obtener ayuda sobre la utilización de este script."
exit 1
